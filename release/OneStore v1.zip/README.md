# OneStore

Welcome to onestore, before we get started here are a few things to remember

- Do NOT share your session.json or your keyphrases.txt (These files are stored on your computer for your ease of access, not for others to use)
- You would need the packages in requirements.txt on your computer, to easy install them run the following command on your computer (make sure python is installed)

  `pip install -r requirements.txt`

## Support

Create an issue on our github page
